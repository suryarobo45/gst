<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registerlogin</title>
    <?php include 'head.php'; ?>
</head>

<body>
    <?php include 'header.php'; ?>
    <style>
        .upload-container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
        }

        form {
            margin-top: 20px;
        }

        #xl-file {
            display: none;
        }

        .xl-file-label {
            color: #fff;
            border-radius: 10px;
            margin-top: 8px;
            padding: 5px 10px;
            margin-left: -20px;
            font-size: 20px;
            background-color: black;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif !important;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 8px 20px;
            border: none;
            letter-spacing: 1px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>

    <div class="container-xxl upload-container">
        <div class="row ">
            <div class="col-lg-12">
                <div class="row mt-5">
                    <div class="col-lg-10"></div>
                    <div class="col-lg-2 mt-5">
                        <button type="button" class="btn upload-btn" data-bs-toggle="modal" data-bs-target="#uploadModal">
                            xl-upload
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">XL-upload page</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="upload-container me-5">
                        <form action="" method="post" enctype="multipart/form-data">
                            <input type="file" id="xl-file" name="file" accept="image/*" onchange="updateFileName()">
                            <label for="xl-file" class="xl-file-label" id="xl-file-label">Choose file</label>
                            <div class="row mt-3">
                                <div class="col-lg-4"></div>
                                <div class="col-lg-4"><button type="submit">Import</button></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function updateFileName() {
            const fileInput = document.getElementById("xl-file");
            const fileLabel = document.getElementById("xl-file-label");

            if (fileInput.files.length > 0) {
                fileLabel.textContent = fileInput.files[0].name;
            } else {
                fileLabel.textContent = "Choose file...";
            }
        }
    </script>
</body>

</html>
